﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereTest : MonoBehaviour {
    public LayerMask playerMask;
    public LayerMask agentsAndMapMask;
    public float searchRadius = 5.0f;
    public Camera camera;


    Vector3 frustumCenter;
    Plane[] frustumPlanes;

    // Use this for initialization
    void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {

        //For giving the spheres at the center of the frustum, not the tank
        frustumCenter = transform.forward.normalized * (searchRadius / 2);

        Collider[] playerColliders = Physics.OverlapSphere(transform.position + frustumCenter, searchRadius, playerMask);

        foreach (Collider col in playerColliders)
        {
            Vector3 direction = transform.position - col.transform.position;
            frustumPlanes = GeometryUtility.CalculateFrustumPlanes(camera);
            if (GeometryUtility.TestPlanesAABB(frustumPlanes, col.bounds))
            {               
                if (!Physics.Raycast(transform.position, direction, Mathf.Infinity, agentsAndMapMask))
                    Debug.Log(col.name + " has been detected!");
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        if (this.isActiveAndEnabled)
        {
            // Display the explosion radius when selected
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position + frustumCenter, searchRadius);
        }
    }
}
